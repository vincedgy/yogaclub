export class Teacher {
    id: number;
    firstName: string;
}