/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { TeachersComponent } from './teachers.component';

describe('Component: Teachers', () => {
  it('should create an instance', () => {
    let component = new TeachersComponent();
    expect(component).toBeTruthy();
  });
});
